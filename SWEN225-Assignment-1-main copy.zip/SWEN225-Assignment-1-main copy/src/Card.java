
public interface Card {
	
	public String getName();
	
	public boolean setName(String name);
	
	public String toString();

}
