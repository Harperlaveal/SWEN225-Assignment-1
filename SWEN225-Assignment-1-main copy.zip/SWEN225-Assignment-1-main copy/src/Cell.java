public class Cell{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Cell(){}

  //------------------------
  // INTERFACE
  //------------------------

  public void delete(){}

}