public class Board{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Board(){}

  //------------------------
  // INTERFACE
  //------------------------

  public void delete(){}

}