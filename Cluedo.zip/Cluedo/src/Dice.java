public class Dice{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Dice(){}

  //------------------------
  // INTERFACE
  //------------------------

  public void delete(){}

}